D	a.php
A	upgrade/cli.php
A	upgrade/files.php
A	upgrade/index.html
